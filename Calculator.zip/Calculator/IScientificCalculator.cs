public interface IScientificCalculator
{
    double SquareRoot(double x);
    double Power(double x, double y);
}