﻿ScientificCalculator scientificCalculator = new ScientificCalculator();

Console.WriteLine(scientificCalculator.Add(5, 3)); 
Console.WriteLine(scientificCalculator.Subtract(5, 3)); 
Console.WriteLine(scientificCalculator.Multiply(5, 3)); 
Console.WriteLine(scientificCalculator.Divide(5, 3)); 
Console.WriteLine(scientificCalculator.SquareRoot(16)); 
